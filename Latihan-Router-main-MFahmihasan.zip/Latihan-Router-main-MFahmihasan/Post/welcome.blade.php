<!DOCTYPE html>
<html>
    <head>
        <title>wellcome</title>
    </head>
    <body>
        <h1>Wellcome to my vlog</h1>
        <p> This is the wellcom to my laravel apllication </p>

        <a href="{{route('post.index')}}">
            <button>View all post</button>
        </a>
    </body>
</html>